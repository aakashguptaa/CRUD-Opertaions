import { Component, OnInit } from '@angular/core';
import { CrudserviceService } from '../services/crudservice.service';
import { Router } from '@angular/router';
import { Users } from '../model/users';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {
Users:Users;
  getusers: any;
  constructor(private service: CrudserviceService, private router: Router) {
this.Users=new Users();
   }

  postUsers(form) {
    if(form.valid){
      this.service.postUsers(this.Users).subscribe((data) => {
      
        this.router.navigateByUrl('/userdetails', { skipLocationChange: true }).then(() =>
      this.router.navigate(['userdetails/'+'12']));
      })
    }
    else{
      alert('Please Enter Valid information');
    }
        
    
    
      
      }

  delete(id: any) {
    this.service.delete(id).subscribe((data) => {
      this.ngOnInit();
    })
  }

  edit(id: any) {
    this.router.navigate(['edit/' + id])

  }


  ngOnInit() {
    
    this.service.getByid().subscribe((data) => {
      this.getusers = data
    })
  }

}
