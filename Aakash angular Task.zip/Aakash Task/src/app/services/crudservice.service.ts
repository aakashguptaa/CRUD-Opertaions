import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Users } from '../model/users';
import { Register } from '../model/register';
@Injectable({
  providedIn: 'root'
})
export class CrudserviceService {

  constructor(private htc: HttpClient) { }

  submit(users: Register): Observable<any> {  // Login Check
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post('http://localhost:3000/Users', JSON.stringify(users), httpOptions);
  }

  postUsers(users: Users): Observable<any> {  // Login Check
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post('http://localhost:3000/Users', JSON.stringify(users), httpOptions);
  }


  getByid(): Observable<any> {  // Login Check
    return this.htc.get('http://localhost:3000/Users', { responseType: 'json' });
  }

  delete(id: any): Observable<any> {  // Login Check
    return this.htc.delete('http://localhost:3000/Users/' + id, { responseType: 'json' });
  }

  get1(id: any): Observable<any> {
    {
      return this.htc.get('http://localhost:3000/Users/' + id, { responseType: 'json' });
    }
  }

  edit(id: any, Users: Users): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put('http://localhost:3000/Users/' + id, JSON.stringify(Users), httpOptions);
  }
}
