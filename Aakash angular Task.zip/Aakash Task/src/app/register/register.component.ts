import { Component, OnInit } from '@angular/core';
import { Register } from '../model/register';
import { CrudserviceService } from '../services/crudservice.service';
import { Users } from '../model/users';
import {Router} from '@angular/router'
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  Users: Register
confirmpsw:any;
  constructor(private service: CrudserviceService,private router:Router) {
    this.Users = new Register();
  }


  submit(form) {
    alert(form.valid)
alert((form.valid==false))

    if ((form.valid === false) || (this.Users.Password!=this.confirmpsw)) {
      alert("Invalid Data")
    }
    else {
      alert(JSON.stringify(this.Users))
      
      this.router.navigate(['login'])
    }

  }

  ngOnInit() {
  }

}
